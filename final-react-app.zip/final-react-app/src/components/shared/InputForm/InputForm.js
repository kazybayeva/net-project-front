import React from "react";

function InputForm({ label, required, className, type,
                                value, name, touched, onChange,
                                onBlur, placeholder, error}) {
  return (
    <div className="input-container">
      <label className="input-label">
        {label}
        {required && <span className="text--red">*</span>}
      </label>
      <input
        className={`input ${className} ${touched && error ? "input--error" : ""} `}
        type={type ? type : "text"}
        value={value}
        name={name}
        onChange={onChange}
        onBlur={onBlur}
        placeholder={placeholder}
      />
      {touched && error && <p className="input-error">{error}</p>}
    </div>
  );
}

export default InputForm;
