import React from 'react';

import './Pagination.scss';

const Pagination = ({ postPerPage, totalPosts, paginate }) => {
    const pageNumbers = [];

    for(let i=1; i<=Math.ceil(totalPosts / postPerPage); i++){
        pageNumbers.push(i);
    }

    return (
        <nav>
            <ul className="page-items-list">
                {pageNumbers.map(number => (
                    <li className="page-item" key={number}>
                        <button onClick={()=> paginate(number)} className="page-btn">
                            {number}
                        </button>
                    </li>
                ))}
            </ul>
        </nav>
    );
}

export default Pagination;
