import React, { Component } from 'react';
import { NavLink, Link } from "react-router-dom";
import { connect } from "react-redux";

import { logout } from '../../../_actions/auth.action';

import SearchBox from '../../search';

import "./Navbar.scss";

class Navbar extends Component {

  

  handleSubmit = (e) => {
    e.preventDefault();
    this.props.logout();
  }

  render(){

  const { loggedIn, user } = this.props.auth;

  const forUser = (
      <>
        <NavLink exact className="nav-link login-link" to="/login"> Login </NavLink>
      </>
    );

  const forAuthUser = (
      <div className="nav__top-right">
        <Link className="profile-link" to="/profile">{ user  }</Link>
        <button className="logout-button" onClick={this.handleSubmit}> Logout </button>
      </div>
  );

  

    return (

      <nav className="navbar">
          <div className="nav__top">
              <div><NavLink exact className="logo" to="/home"><h3>MOVIE<b>REV</b></h3> </NavLink></div>
              <div className="top__right">
                  {loggedIn ? forAuthUser : forUser}
              </div>
          </div>

          <div className="nav__bottom">
                  <li className="nav-item"> <NavLink exact className="nav-link" to="/home"> NEWS </NavLink> </li>
                  <li className="nav-item"> <NavLink  className="nav-link" to="/reviews"> REVIEWS </NavLink> </li>
                  <li className="nav-item"> <NavLink  className="nav-link" to="/moviesreviews"> MOVIES </NavLink> </li>
                  <li className="nav-item"> <NavLink  className="nav-link" to="/add_post"> Post on MovieRev </NavLink> </li>
                  <li className="nav-item search-item"> <SearchBox/></li>
          </div>
      </nav>
    );
  }
}


function mapStateToProps(state){
  return {
    auth: state.auth
  };
  
}


export default connect(mapStateToProps, { logout })(Navbar);