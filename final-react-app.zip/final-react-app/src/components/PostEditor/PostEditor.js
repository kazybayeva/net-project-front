import React, { Component } from 'react';
import { withRouter } from "react-router-dom";
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';

import { postService } from '../../_services/post.service';
import { userService } from '../../_services/user.service';


class PostEditor extends Component {
    state = {
        title: '',
        body: '',
        author: '',
        likes: 0,
        posts: {}
    }


    onChange = (e) => {
        this.setState({body: e});
    };

    onInputChange = (e) => {
        this.setState({title: e.target.value})
    }


    handleSubmit = (e) => {
        e.preventDefault();
        const userID = localStorage.getItem('userID');
        
        userService.getUser(userID).then(res => {
            const post = {
                title: this.state.title,
                body: this.state.body,
                author: res.username,
                likes: []
            };
            postService.addPost(post.title, post.body, "05-09-2019", post.author, post.likes);
            postService.getLastPostID().then(res =>{
                const id = res+1;
                this.props.history.push("/posts/"+id);
            });

            this.setState({
                title: '',
                body: ''
            });
        });

    }


    render(){
        return (
            <div className="container">
                <form onSubmit={this.handleSubmit}>
                    <div className="form-group">
                        <input 
                        value={this.state.title}
                        placeholder="Add title here"
                        onChange={this.onInputChange}
                        />
                    </div>
                    <div className="form-group">
                        <ReactQuill 
                        modules={PostEditor.modules}
                        formats={PostEditor.formats}
                        value={this.state.body}
                        placeholder="Enter here your opinion on the latest movie you've seen! :)"
                        onChange={this.onChange}
                        />
                    </div>
                    <button className="btn btn-primary">Add Post</button>
                </form>
            </div>
        );
    }
}

PostEditor.modules = {
    toolbar: [
        [{'header': '1'}, {'header': '2'}, {'font': [] }],
        [{'size': [] }],
        ['bold', 'italic', 'underline', 'blockquote'],
        [{'list': 'ordered'}, {'list': 'bullet'}],
        ['link', 'image'],
        ['clean']
    ]
}

PostEditor.formats = [
    'header',
    'font',
    'size',
    'bold',
    'italic',
    'underline',
    'blockquote',
    'list',
    'bullet',
    'link',
    'image'
]

export default withRouter(PostEditor);