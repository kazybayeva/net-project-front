import React, { Component } from 'react';
import renderHTML from 'react-render-html';
import { connect } from 'react-redux';

import { userService } from '../../_services/user.service';
import { getLikesOfPost } from '../../_actions/post.action';

class PostDetail extends Component {

    state = {
        isAuthor: false,
        userID: 0
    }

    componentDidMount(){
        const userID = localStorage.getItem('userID');
        if(userID){
            userService.getUser(userID).then(res =>{
                if(res.username === this.props.postDetails.author){
                    this.setState({ 
                        isAuthor: true
                      });
                }
            })
        }
        

        this.setState({ 
            userID: userID
        });

        this.props.getLikesOfPost(this.props.postDetails.id);
    }

    deletePost = postID => {
        this.props.delete(postID);
    }

    likePost = (userID, postID) => {
        this.props.like(userID, postID);
    }

    render(){
        let { likes } = this.props.post;

        return (
            <div className="container">
                <div className="post-title">
                    <h1>{this.props.postDetails.title}:  {this.props.postDetails.subtitle}</h1>
                    <h4 className="post-author">posted by @{this.props.postDetails.author}</h4>
                    <p className="post-date">{this.props.postDetails.date}</p>
                </div>
                
                <div className="post-banner">
                    <img className="photo" src={require('../../assets/images/' + this.props.postDetails.id +'.jpg')} alt={this.props.postDetails.id}/>
                </div>
                <div className="post-body">
                    { renderHTML(this.props.postDetails.body) }
                </div>

                <div className="likes">
                    <span >{likes}</span>
                    <button type="button" className= {`btns ${this.props.toggleLike ? "btn-liked" : "btn-like"}`} onClick={() =>  this.likePost(this.state.userID, this.props.postDetails.id) }><i className="far fa fa-heart"></i></button>
                 </div>

                 { this.state.isAuthor &&
                    <button type="button" className="btns btn-delete" onClick={() => { if (window.confirm('Are you sure you wish to delete this post?')) this.deletePost(this.props.postDetails.id) } }><i className="far fa fa-trash"></i></button>
                }
            </div>
        );
    }
}

const mapStateToProps = (state) => ({
    post: state.post
});

export default connect(mapStateToProps, { getLikesOfPost })(PostDetail);