import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import WOW from 'wowjs';

import { commentService } from '../../_services/comments.service';
import { postService } from '../../_services/post.service';

import './Post.scss';

class Post extends Component {

  state = {
    comments: 0,
    likes: 0
  }

  componentDidMount(){
    var wow = new WOW.WOW({live:false});
    wow.init();

    commentService.commentsCounter(this.props.post.id).then(res => {
      this.setState({ comments: res});
    })

    postService.getLikes(this.props.post.id).then(res => {
      if(res.length){
         this.setState({ likes: res.length});
      }
    })
  }
    
    render() {

      const { post } = this.props;
      const { comments, likes } = this.state;


      return (
          <div className="post-card wow fadeIn" key={post.id} >
              <img className="photo" src={require('../../assets/images/' + post.id +'.png')} alt={post.id}/>
              <div className="card-content">
                <h1 className="card-title">{post.title}</h1>
                <h2 className="card-subtitle">{post.subtitle}</h2>
                
                <div className="read-more">
                <div className="bottom-content">
                  <span className="icons"><i className="fas fa fa-comment"></i>   {comments}  </span><br/>
                  <span className="icons"><i className="far fa fa-heart"></i>   {likes}</span>
                </div>
                  <NavLink to={'/posts/' + post.id}><button className='btn detail'>Read more</button></NavLink>
                </div>
              </div>
            </div>
      );
    }
  }
  

  export default Post;