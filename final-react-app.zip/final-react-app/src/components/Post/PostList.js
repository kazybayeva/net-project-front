import React, { Component } from 'react';

import Post from './Post';
import Pagination from '../shared/Pagination/Pagination';

import { postService } from '../../_services/post.service';
import { userService } from '../../_services/user.service';

class PostList extends Component {
    state = {
        posts: [],
        loading: false,
        currentPage: 1,
        postPerPage: 10
    }

      
    componentDidMount() {

        if(!this.props.author){
            postService.getAllPosts()
                .then(res => {
                    this.setState({posts: res});
            })
        } else {
            userService.getUser(this.props.author).then(res =>{
                postService.getAuthorPosts(res.username)
                .then(res => {
                    this.setState({posts: res});
                })
            })
            
        }

    };

    paginate = (pageNumber) => {
    this.setState({ currentPage: pageNumber });
    };
      
    render(){

        const { currentPage, postPerPage, posts } = this.state;

        const indexOfLastPost = currentPage * postPerPage;
        const indexOfFirstPost = indexOfLastPost - postPerPage;
        const currentPosts = posts.slice(indexOfFirstPost, indexOfLastPost);

        const postDetails = currentPosts.length ? (
            currentPosts.map(post =>{
              return(
                <Post 
                    post={post} 
                    key={post.id}
                />
              )} ) ) : (
                <div>No posts yet</div>
            ); 
        
        return(
            <div>
                {postDetails}
                <div className="pagination">
                    <Pagination 
                        postPerPage={postPerPage} 
                        totalPosts={posts.length} 
                        paginate={this.paginate}
                    />
                </div>
            </div>
        );
    }
}

export default PostList;