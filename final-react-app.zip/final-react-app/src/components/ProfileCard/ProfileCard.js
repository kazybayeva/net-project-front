import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from "react-router-dom";

import { userService } from '../../_services/user.service';

import './ProfileCard.scss';

class ProfileCard extends Component {
    state = {
        user: {}
    }

    componentDidMount(){
        const { loggedIn } = this.props.auth;

        if(loggedIn){
            const userID = localStorage.getItem('userID');
            userService.getUser(userID)
            .then(res => {
                this.setState({ user: res });
            });
        } 
        // else {
        //     alert("You have to login first!");
        //     this.props.history.push("/login");
        // }
        
    }

    render(){

        const { user } = this.state;

        return(
            <div className="profile-card">
                <header>
                    <img src={require('../../assets/images/profile.jpg')} alt="profile_photo"/>
                    <h5>{user.name}</h5>
                    <h6>@{user.username}</h6>
                </header>

                <div className="profile-details">
                    <p></p>
                    <p>birth: {user.birth}</p>
                    <p>site: {user.website}</p>
                </div>
            </div>
        );
    }
}

function mapStateToProps(state){
    return {
      auth: state.auth
    };
    
  }

  
export default withRouter(connect(mapStateToProps)(ProfileCard));