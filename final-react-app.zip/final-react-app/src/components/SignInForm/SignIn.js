import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from "react-router-dom";
import { Formik, ErrorMessage } from 'formik';

import InputForm from '../../components/shared/InputForm/InputForm';

import { login } from '../../_actions/auth.action';
import { userService } from '../../_services/user.service';

import './SignIn.scss';

class SignIn extends Component {

    state = {
        formError: ''
      };

    handleSubmit = (values) => {
        const { username, password } = values;
        console.log("handleSubmit was called");
        
        userService.login(username, password)
            .then(res => {
                if(res){
                    this.props.login(username, password);
                    this.props.history.push("/home");
                } 
            })
            .catch(error => {
                if (error.response) {
                    this.setState({ formError: error.response.data.error });
                  } else {
                    this.setState({ formError: error.message });
                  }
            });
    }


    validateForm = values => {
        const errors = {};
    
        if (!values.username) {
          errors.username = "Заполните поле";
        }
    
        if (!values.password) {
          errors.password = "Заполните поле";
        } else if (values.password.length < 4) {
          errors.password = "Пароль должен быть как минимум 6 символов";
        }

        return errors;
      };




    renderForm = ({ handleSubmit, handleChange, errors, touched }) => (
        <div className="card">
            <h5 className="card-header info-color white-text text-center py-4">
                <strong>Sign in</strong>
            </h5>
            <div className="card-body px-lg-5 pt-0">
                <form className="text-center" onSubmit={handleSubmit}>
                    <div className="md-form">
                        <InputForm 
                                type="text" 
                                name = "username"
                                label = "Username:"
                                className="form-control"  
                                error={errors.username} 
                                touched={touched.username}
                                onChange={handleChange}
                        />
                        <ErrorMessage name="username" />
                    </div>
                    <div className="md-form">
                        <InputForm 
                                type="password" 
                                name = "password"
                                label = "Password"
                                className="form-control" 
                                error={errors.password} 
                                touched={touched.password}
                                onChange={handleChange}
                        />
                        <ErrorMessage name="password" />
                        {this.state.formError && (
                            <p className="text--error">{this.state.formError}</p>
                        )}
                    </div>
                    <button type="submit" className="btn btn-outline-info btn-rounded btn-block my-4 waves-effect z-depth-0">Sign in</button>
                </form>
            </div>
        </div>
      );


    render() {
      return (
        <Formik
          onSubmit={this.handleSubmit}
          render={this.renderForm}
          validate={this.validateForm}
          initialValues={{
            username: '',
            password: ''
          }}
        />
      );
    }
  }


  export default withRouter(connect(null, { login })(SignIn));