import React, { Component } from 'react';

import Comment from './Comment';


class CommentsList extends Component {

    render(){
        const { commentsOfPost } = this.props;
        const commentsList = commentsOfPost.length ? (
            commentsOfPost.map(comment =>{
              return(
                <Comment comment={comment} key={comment.id}/>
              )
            })
            ) : (
              <div>No comments yet</div>
            ); 

        return(
            <div className="comments-container">
              <div className="heading comments-heading">
                  <span >Comments</span>
                </div>
                 {commentsList}
            </div>
        );
    }
}

export default CommentsList;