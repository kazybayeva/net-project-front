import React, { Component } from 'react';
import { connect } from 'react-redux';

import { userService } from '../../_services/user.service';
import { addComment } from '../../_actions/comment.action';

import './Comment.scss';

class AddCommentForm extends Component {

    state = {
        postID: 0, 
        body: '', 
        author: '', 
        likes: 0
    };


    onChange = (e) => {
        this.setState({ body: e.target.value })
    }

    handleSubmit = (e) => {
        e.preventDefault();

        const userID = localStorage.getItem('userID');
        const { postID } = this.props.post;

        if(userID){
            userService.getUser(userID)
            .then(res => {
                const comment = {
                    postID: postID,
                    body: this.state.body,
                    author: res.username,
                    likes: 0
                };
        
                this.props.addComment(comment.postID, comment.body, comment.author, comment.likes);

                this.setState({
                    body: ''
                  });
            });
        } else {
            //route to Sign In or pop up window to Sign In
        }

    }

    render(){
        return(
            <div className="comments-form">
                 <form onSubmit={this.handleSubmit}>
                    <div className="form-group">
                        <textarea 
                        className="form-control"
                        value={this.state.body}
                        placeholder="What do you think about this article?"
                        onChange={this.onChange}
                        />
                    </div>
                    <button className="btn btn-primary">Comment</button>
                </form>
            </div>
        );
    }
}

function mapStateToProps (state){
    return{
        post: state.post
    };
}

export default connect(mapStateToProps, { addComment })(AddCommentForm);