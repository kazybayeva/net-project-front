import React from 'react';

import './Comment.scss';

function Comment({ comment }){

    return (  
        <div className="comment-card">
            <div className="card-content">
                <h6 className="comment-author">{comment.author}</h6>
                <p className="comment-body">{comment.body}</p>
              </div>
        </div>
    );
}

export default Comment;