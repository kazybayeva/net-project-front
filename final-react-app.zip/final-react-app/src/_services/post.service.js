import axios from 'axios';

export const postService = {
    getPost,
    addPost,
    deletePost,
    getAllPosts,
    getLastPostID,
    likePost,
    getAuthorPosts,
    getLikes
};


function getAllPosts() {
    return axios.get('http://localhost:3001/posts')
                .then(response => {
                    return response.data;
                });
}

function getPost(postID) {
    return axios.get('http://localhost:3001/posts/' + postID)
                .then(response => {
                    return response.data;
                })
}

function deletePost(postID) {
    return axios.delete('http://localhost:3001/posts/' + postID)
                .then(response => {
                    return response;
                });
}

function addPost (title, body, date, author, likes) {
    return axios.post('http://localhost:3001/posts', {
                    title: title,
                    body: body,
                    date: date,
                    author: author,
                    likes: likes
                })
                .then(response => {
                    getAllPosts();
                    return response;
                })
}


function getLastPostID () {
    return axios.get('http://localhost:3001/posts')
                .then(response => {
                    return response.data.slice(-1)[0].id;
                })
}

function likePost (userID, postID, toggleLike) {
    let likes = [];
    return getPost(postID).then(res => {
                likes = res.likes;

                if(toggleLike){
                    likes.push(userID);
                } else {
                    for(var i = likes.length - 1; i >= 0; i--) {
                        if(likes[i] === userID) {
                            likes.splice(i, 1);
                        }
                    }
                }

                axios.put('http://localhost:3001/posts/'+postID, {
                        title: res.title,
                        body: res.body,
                        date: res.date,
                        author: res.author,
                        likes: likes
                }).then(response => {
                            return response;
                        })
                return likes.length;
    });
}



function getLikes (postID) {
    return axios.get('http://localhost:3001/posts/', {params: {id: postID}} )
                .then(response => {
                    return response.data[0].likes;
                })
}


function getAuthorPosts(author) {
    return axios.get('http://localhost:3001/posts/', {params: {author: author}})
                .then(response => {
                    return response.data;
                });
}