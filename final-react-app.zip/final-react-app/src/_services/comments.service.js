import axios from 'axios';

export const commentService = {
    getComment,
    addComment,
    deleteComment,
    getAllCommentsOfPost,
    commentsCounter
};


function getAllCommentsOfPost(postID) {
    return axios.get('http://localhost:3001/comments?postId=' + postID)
                .then(response => {
                    return response.data;
                });
}

function getComment(commentID) {
    return axios.get('http://localhost:3001/comments/' + commentID)
                .then(response => {
                    return response;
                })
}

function deleteComment(commentID) {
    return axios.delete('http://localhost:3001/comments/' + commentID)
                .then(response => {
                    return response;
                });
}

function addComment (postID, body, author, likes) {
    return axios.post('http://localhost:3001/comments', {
                    postId: postID,
                    body: body,
                    author: author,
                    likes: likes
                })
                .then(response => {
                    getAllCommentsOfPost(postID);
                    return response.data;
                })
}

function commentsCounter(postID) {
    return axios.get('http://localhost:3001/comments/', {params: {postId: postID}})
                .then(response => {
                    return response.data.length;
                })
}
