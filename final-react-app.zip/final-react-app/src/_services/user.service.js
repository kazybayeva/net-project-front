import axios from 'axios';

export const userService = {
    login,
    logout,
    getAllUsers,
    getUser
};


function login(username, password) {
    return getAllUsers().then(res => {
        let user = res.find(user => (user.username === username && user.password === password));
        if(user){
            localStorage.setItem('userID', user.id)
            return true;
        } else {
            return false;
        }
    });
}

function logout() {
    localStorage.removeItem('access_token');
    localStorage.removeItem('userID');
}


function getAllUsers() {
    return axios.get('http://localhost:3001/users')
                .then(response => {
                        return response.data;
                })
}


function getUser(userID) {
    return axios.get('http://localhost:3001/users/' + userID)
                .then(response => {
                    return response.data;
                })
}

