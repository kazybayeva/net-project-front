import React, {Component} from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { Provider } from "react-redux";
import { Chat } from 'react-chat-popup'

import Navbar from './components/shared/Navbar/Navbar';
import LoginPage from './pages/Login/LoginPage';
import HomePage from './pages/Home/HomePage';
import AddingPostLayout from './pages/AddingPostLayout';
import PostDetailLayout from './pages/PostDetailLayout';
import ProfileLayout from './pages/ProfileLayout';
import ReviewsPageLayout from './pages/ReviewsPageLayout';
import SearchLayout from './pages/SearchLayout';

import './App.scss';

import store from "./store";

const NoMatchPage = () => {
  return (
    <h3>404 - Not found</h3>
  );
};

class App extends Component {
  handleNewUserMessage = (newMessage) => {
    console.log(`New message incoming! ${newMessage}`);
    // sending message throught the backend API
  }

  render(){
    return (
      <Provider store={store}>
        <Router>
          <Navbar/>
          <div className="chat">
          <Chat
            handleNewUserMessage={this.handleNewUserMessage}
            title="Let's talk about movies!"
            subtitle="And my cool subtitle"
          />
          </div>
          <Switch>
              <Route path="/home" component={HomePage} />
              <Route exact path="/login" component={LoginPage} />
              <Route exact path="/add_post" component={AddingPostLayout} />
              <Route exact path="/posts/:postID" component={PostDetailLayout} />
              <Route exact path="/profile" component={ProfileLayout} />
              <Route exact path="/reviews" component={ReviewsPageLayout} />
              <Route exact path="/search" component={SearchLayout} />
              <Route component={NoMatchPage} />
          </Switch>
        </Router>
      </Provider>
    );
  }
}

export default App;
