export const LOGIN = 'LOGIN';
export const LOGIN_FAILURE = 'LOGIN_FAILURE';
export const LOGOUT = 'LOGOUT';
export const GET_POST_ID = 'GET_POST_ID';
export const TOGGLE_LIKE_POST = 'TOGGLE_LIKE_POST';
export const GET_LIKES = 'GET_LIKES';
export const COMMENT_ADDED = 'COMMENT_ADDED';
export const GET_COMMENTS = 'GET_COMMENTS';

export const API_URL = 'http://jsonplaceholder.typicode.com';
