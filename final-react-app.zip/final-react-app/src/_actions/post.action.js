import * as type from '../constants';
import { postService } from '../_services/post.service';

export const getPostID = (postID) => dispatch => {
        dispatch({
            type: type.GET_POST_ID,
            payload: +postID
        });
}

export const likePost = (userID, postID, toggleLike) => dispatch => {
    postService.likePost(userID, postID, toggleLike)
    .then(likesCounter => {
        dispatch({
            type: type.TOGGLE_LIKE_POST,
            payload: likesCounter
        });
    });
}

export const getLikesOfPost = (postID) => dispatch => {
    postService.getLikes(postID)
    .then(likesCounter => {
        dispatch({
            type: type.GET_LIKES,
            payload: likesCounter.length
        });
    });
}