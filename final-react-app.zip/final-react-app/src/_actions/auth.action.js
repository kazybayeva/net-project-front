import { userService } from '../_services/user.service';
import * as type from '../constants';

export const login = (username, password) => dispatch => {
  
    localStorage.setItem("access_token", `${username}:${password}`);
      dispatch({
        type: type.LOGIN,
        username: username
      });
  };

  
export const logout = () => dispatch => {
      userService.logout();
      
      dispatch({
        type: "LOGOUT"
      });
}