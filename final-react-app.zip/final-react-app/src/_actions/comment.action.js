import { commentService } from '../_services/comments.service';

import * as type from '../constants';


export const getCommentsOfPost = (postID) => dispatch => {
    commentService.getAllCommentsOfPost(postID)
    .then(res => {
        dispatch({
            type: type.GET_COMMENTS,
            payload: res
        });
    });
}


export const addComment = (postID, body, author, likes) => dispatch => {
    commentService.addComment(postID, body, author, likes)
    .then(res => {
        commentService.getAllCommentsOfPost(postID)
        .then(res => {
            dispatch({
                type: type.COMMENT_ADDED,
                comments: res
            });
        });
    });
}