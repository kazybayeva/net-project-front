import React from "react";
import SignIn from './../../components/SignInForm/SignIn';

import "./LoginPage.scss";

export default function LoginPage() {
  return (
      <div className="login">
        <div className="login__section">
            <SignIn/>
        </div>
    </div>
  );
}
