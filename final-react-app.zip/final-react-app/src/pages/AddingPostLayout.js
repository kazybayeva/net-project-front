import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

import './layouts.scss';

import PostEditor from '../components/PostEditor/PostEditor';

function AddingPostPage({ auth }) {
        const pageView = auth.loggedIn ? (
            <PostEditor/>
        ) : (
            <div className="container">
                <div className="addPost_button">
                    <Link to="/login" className="btn btn-primary">Firstly you need to Sign In!</Link>
                </div>
                <div className="addPost_banner">
                    <img className="photo" src={require('../assets/images/add__post.jpg')} alt="addPost__banner"/>
                </div>
            </div>
        );

        return(
            <>
                {pageView}
            </>
        );
}

function mapStateToProps(state){
    return {
      auth: state.auth
    };
    
  }

export default connect(mapStateToProps)(AddingPostPage);
