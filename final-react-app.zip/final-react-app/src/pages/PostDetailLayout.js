import React, { Component } from 'react';
import { connect } from 'react-redux';

import PostDetail from '../components/Post/PostDetail';
import AddCommentForm from '../components/Comments/AddCommentForm';
import CommentsList from '../components/Comments/CommentsList';

import { postService } from '../_services/post.service';
import { getCommentsOfPost } from '../_actions/comment.action';
import { getPostID, likePost } from '../_actions/post.action';

class PostDetailLayout extends Component{
    state = {
        post: {},
        isLoading: false,
        commentsOfPost: [],
    }

    componentDidMount(){
        let post_id = this.props.match.params.postID;

        postService.getPost(post_id)
            .then(res =>{
                this.setState({
                    post: res,
                    isLoading: true
                 });
                    this.props.getCommentsOfPost(post_id);
            })
        this.props.getPostID(post_id);
    }



    deletePost = postID => {
        postService.deletePost(postID)
        .then(res => {
            this.props.history.push("/profile");
        });
    }


    likePost = (userID, postID) => {
        this.setState(state => {
            const { post } = state;
            post.toggleLike = !post.toggleLike;
          });
        this.props.likePost(+userID, postID, this.state.post.toggleLike);
    }


    render(){

        const { comments } = this.props.comments;
        const postDetails  = this.state.post;
    
        return(
            <div>
                {this.state.isLoading && 
                    <PostDetail 
                        postDetails = {postDetails} 
                        delete = {this.deletePost}
                        like = {this.likePost}
                        toggleLike = {postDetails.toggleLike}
                    />
                }
                
                <CommentsList commentsOfPost = {comments} />
                <AddCommentForm/>
            </div>
        ); 
    }
}

const mapStateToProps = (state) => ({
    comments: state.comment
});

export default connect(mapStateToProps, { getCommentsOfPost, getPostID, likePost })(PostDetailLayout);