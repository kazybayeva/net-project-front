import React, { Component } from "react";

// import App from '../components/app-main';
let App = require('../components/app-main');

export default class SearchLayout extends Component{
    constructor(props) {
        super(props)
    
        this.state = {
          movieID: 157336 
        }
      }

    render(){
        return (
            <a>Search</a>
        );}




}
