import React, { Component } from "react";

import PostList from './../../components/Post/PostList';

import "./HomePage.scss";


export default class HomePage extends Component{



render(){
  

  return (
    <div className="news-section">
        <div className="banner">
        </div>
        <div className="heading">
            <span >News</span>
        </div>
        <PostList/>
    </div>
  );
}
}
