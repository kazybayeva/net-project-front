import React, { Component } from "react";

import PostList from './../components/Post/PostList';


export default class ReviewsPageLayout extends Component{
    render(){
        return (
            <div className="news-section">
                <div className="heading">
                    <span >Reviews</span>
                </div>
                <PostList/>
            </div>
        );}
    }
