import React from 'react';

import ProfileCard from '../components/ProfileCard/ProfileCard';
import PostList from '../components/Post/PostList';

import './layouts.scss';

function ProfileLayout () {
    const userID = localStorage.getItem('userID');
        return(
            <div className="section">
                <ProfileCard />
                <div className="section-list">
                    <h4 id="list-header">My Posts:</h4><br/>
                    <PostList author={userID}/>
                </div>
            </div>
        );
}

export default ProfileLayout;