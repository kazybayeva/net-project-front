import React, { Component } from "react";

export default class MoviesPageLayout extends Component{
    render(){
        return (
            <div className="movies-section">
                
            </div>
        );}
    }
