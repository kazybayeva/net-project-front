import * as type from '../constants';

const initialState = {};

export default function getPostDetails (state = initialState, action){
    switch(action.type){
        case type.GET_POST_ID:
            return {
                ...state,
                postID: action.payload
            };
        case type.TOGGLE_LIKE_POST:
            return {
                ...state,
                likes: action.payload
            };
        case type.GET_LIKES:
            return {
                ...state,
                likes: action.payload
            }
        default:
            return state
        }
}