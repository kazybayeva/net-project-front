import * as type from '../constants';

let token = localStorage.getItem('access_token');
const initialState = token ? { loggedIn: true, user: token } : {};

export default function authentication (state = initialState, action){
    switch(action.type){
        case type.LOGIN: 
            return {
                ...state,
                loggedIn: true,
                user: action.username
            };
        case type.LOGOUT:
            return {};
        case type.LOGIN_FAILURE:
            return {};
        default:
            return state
        }
}