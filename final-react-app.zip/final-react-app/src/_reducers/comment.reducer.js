import * as type from '../constants';

const initialState = {
    comments: []
};

export default function getComments (state = initialState, action){
    switch(action.type){
        case type.COMMENT_ADDED:
            return {
                ...state,
                comments: action.comments 
            };
        case type.GET_COMMENTS:
            return {
                ...state,
                comments: action.payload
            }
        default:
            return state
        }
}